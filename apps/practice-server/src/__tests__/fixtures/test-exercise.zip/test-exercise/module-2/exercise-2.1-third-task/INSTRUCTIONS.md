# Exercise 2.1
Third task instructions.
