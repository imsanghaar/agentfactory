# Test Exercise
Top-level CLAUDE.md for test fixture.
