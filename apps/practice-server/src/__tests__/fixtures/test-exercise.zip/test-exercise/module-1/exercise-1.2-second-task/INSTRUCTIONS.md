# Exercise 1.2
Second task instructions.
